package io.github.diegoflassa.littledropsofrain.data.dao

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.firestoreSettings
import com.google.firebase.ktx.Firebase
import com.google.type.DateTime
import io.github.diegoflassa.littledropsofrain.data.DataChangeListener
import io.github.diegoflassa.littledropsofrain.data.entities.Message
import java.util.*


//DFL - Classe de Acesso a dados. Aqui vc coloca as FORMAS DE ACESSAR os dados
object MessageDao {

    private var mListener: DataChangeListener? = null
    var all: MutableList<Message> = ArrayList()
    private const val TAG: String = "MessageDao"

    init {
        setup()
        setupCacheSize()
    }

    private lateinit var db : FirebaseFirestore

    private fun setup() {
        // [START get_firestore_instance]
        db = Firebase.firestore
        // [END get_firestore_instance]

        // [START set_firestore_settings]
        val settings = firestoreSettings {
            isPersistenceEnabled = true
        }
        db.firestoreSettings = settings
        // [END set_firestore_settings]
    }

    private fun setupCacheSize() {
        // [START fs_setup_cache]
        val settings = firestoreSettings {
            cacheSizeBytes = FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED
        }
        db.firestoreSettings = settings
        // [END fs_setup_cache]
    }

    fun loadAll(listener: DataChangeListener){
        mListener = listener
        db.collection("messages")
            .get()
            .addOnSuccessListener { result ->
                var message : Message
                for (document in result) {
                    message = document.toObject(Message::class.java)
                    //message = Message(document.data)
                    Log.d(TAG, "${document.id} => ${document.data}")
                    all.add(message)
                }
                mListener!!.onDataLoaded(all)
            }
            .addOnFailureListener { exception ->
                Log.d(TAG, "Error getting documents: ", exception)
            }
    }

    fun loadAllByIds(messageIds: IntArray?, listener: DataChangeListener): List<Message>?{

        return ArrayList()
    }

    fun findByTitle(title: String?, listener: DataChangeListener): Message? {
        return null
    }

    fun findByCreationDate(date: DateTime?, listener: DataChangeListener): List<Message>? {
        return null
    }

    fun findByRead(read: Boolean?, listener: DataChangeListener): List<Message>? {

        return null
    }

    fun insertAll(vararg messages: Message) {
        for( message in messages) {
            val data = message.toMap()
            val id = db.collection("messages").document().id
            db.collection("messages").document(id).set(message)
        }
    }

    fun insert(message: Message) {
        val data = message.toMap()
        val id = db.collection("messages").document().id
        db.collection("messages").document(id).set(data).addOnSuccessListener{
            Log.d(TAG, "Success")
        }.addOnFailureListener{
            Log.d(TAG, it.message.toString())
        }
    }

    fun delete(message: Message?) {

    }

    fun deleteAll() {}
}