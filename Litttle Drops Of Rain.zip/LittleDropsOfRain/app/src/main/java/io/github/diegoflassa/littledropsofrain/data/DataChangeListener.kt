package io.github.diegoflassa.littledropsofrain.data

import io.github.diegoflassa.littledropsofrain.data.entities.Message

interface DataChangeListener {
    fun onDataLoaded(messages: List<Message>)
}