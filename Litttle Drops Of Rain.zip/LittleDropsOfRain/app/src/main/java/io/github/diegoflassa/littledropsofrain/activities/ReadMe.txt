Contains all the activities. Classes are all named with Activity at the end. That way, you can
immediately know what it is when reading Java code that doesn't have its full package name.