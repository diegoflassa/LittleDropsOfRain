package io.github.diegoflassa.littledropsofrain.helpers

import java.text.SimpleDateFormat
import java.util.*

class Helper {

    companion object{
        fun getDateTime(date: Date): String? {
            return try {
                val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                sdf.format(date)
            } catch (e: Exception) {
                e.toString()
            }
        }

    }


}