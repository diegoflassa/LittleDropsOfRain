Contains any class related to signing a user in. I create a local account and having all related
classes together is very handy.