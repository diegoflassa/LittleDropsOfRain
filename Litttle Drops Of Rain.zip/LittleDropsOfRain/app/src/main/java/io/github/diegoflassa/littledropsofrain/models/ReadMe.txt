Contains all local models. When syncing from an HTTP API I parse the JSON into these Java objects
using Jackson. I also pull Cursor rows into these models as well.