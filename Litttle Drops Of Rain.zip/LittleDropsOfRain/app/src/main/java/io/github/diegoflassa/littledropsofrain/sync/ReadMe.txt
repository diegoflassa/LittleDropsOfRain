Contains all classes related to syncing. I use a SyncAdapter to pull data from an HTTP API.
In addition to the SyncAdapter a SyncService is required, so I created a package.