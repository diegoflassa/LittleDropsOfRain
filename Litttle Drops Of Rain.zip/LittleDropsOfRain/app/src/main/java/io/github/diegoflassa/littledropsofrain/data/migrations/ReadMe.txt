Contains all of my SQLite migrations. I created a class for migrations, read about it here, and put
them all in this package.