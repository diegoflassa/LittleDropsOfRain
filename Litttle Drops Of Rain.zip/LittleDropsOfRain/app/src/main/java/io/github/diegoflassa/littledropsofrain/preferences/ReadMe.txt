Contains all classes for custom preferences. When creating the preferences I required a custom
PreferenceDialog as well as a custom PreferenceCategory. They live here.