Contains helper classes. A helper class is a place to put code that is used in more than one place.
I have a DateHelper for instance. Most of the methods are static.