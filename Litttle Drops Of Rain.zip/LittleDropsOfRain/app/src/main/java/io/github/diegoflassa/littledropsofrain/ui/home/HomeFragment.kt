package io.github.diegoflassa.littledropsofrain.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources.getDrawable
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.auth.AuthUI
import io.github.diegoflassa.littledropsofrain.R
import io.github.diegoflassa.littledropsofrain.adapters.ProductListAdapter
import io.github.diegoflassa.littledropsofrain.models.ProductViewModel
import io.github.diegoflassa.littledropsofrain.models.ProductViewModelFactory
import io.github.diegoflassa.littledropsofrain.data.dao.MessageDao
import io.github.diegoflassa.littledropsofrain.data.entities.Message
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var btnChooser: Button
    private lateinit var btnLogout: Button
    private lateinit var productViewModel: ProductViewModel

    companion object{
        const val TAG ="HomeFragment"
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProvider.NewInstanceFactory().create(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        val textView: TextView = root.findViewById(R.id.text_home)
        btnChooser= root.findViewById(R.id.authButton)
        btnChooser.setOnClickListener {  }
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        btnLogout= root.findViewById(R.id.authButton)
        btnLogout.setOnClickListener {
            GlobalScope.launch {
                val message: Message= Message()
                message.title = "Title title title"
                message.message = "Aaaaaaaa"
                MessageDao.insert( message )
            }
            logout()
        }
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })

        val recyclerView = root.findViewById<RecyclerView>(R.id.recyclerview)
        val adapter = ProductListAdapter(requireContext())
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val itemDecoration = DividerItemDecoration(this.context, DividerItemDecoration.VERTICAL)
        itemDecoration.setDrawable(getDrawable(requireContext(), R.drawable.card_item_divider)!!)
        recyclerView.addItemDecoration(itemDecoration)

        productViewModel = ViewModelProvider(this,
            ProductViewModelFactory(
                requireActivity().application
            )
        ).get(
            ProductViewModel::class.java)
        productViewModel.allProducts.observe(viewLifecycleOwner, Observer { words ->
            // Update the cached copy of the words in the adapter.
            words?.let { adapter.setWords(it) }
        })

        return root
    }

    private fun logout(){
        AuthUI.getInstance().signOut(requireContext())
    }
}