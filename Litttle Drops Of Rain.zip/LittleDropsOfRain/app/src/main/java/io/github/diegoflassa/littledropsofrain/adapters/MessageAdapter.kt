package io.github.diegoflassa.littledropsofrain.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import io.github.diegoflassa.littledropsofrain.R
import io.github.diegoflassa.littledropsofrain.data.entities.Message
import io.github.diegoflassa.littledropsofrain.helpers.Helper


internal class MessageAdapter(
    val context: Context,
    messages: List<Message>
) :
    RecyclerView.Adapter<MessageAdapter.AppViewHolder>() {
    private val data: List<Message> = messages

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AppViewHolder {
        val itemView: View =
            LayoutInflater.from(context).inflate(R.layout.recyclerview_item_message, parent, false)
        return AppViewHolder(itemView)
    }

    override fun onBindViewHolder(
        holder: AppViewHolder,
        position: Int
    ) {
        holder.bind(data[position], context)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    internal class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.msg_title)
        private val creationDate: TextView = itemView.findViewById(R.id.msg_creation_date)
        private val sender: TextView = itemView.findViewById(R.id.msg_sender)
        private val edtMessage: EditText = itemView.findViewById(R.id.msg_message)
        private val read: Switch = itemView.findViewById(R.id.msg_read)

        fun bind(message: Message, context : Context) {
            title.text = context.getString(R.string.msg_title, message.title)
            if(message.creationDate!=null) {
                creationDate.text = context.getString(R.string.msg_creation_date, Helper.getDateTime(message.creationDate!!.toDate()))
            }
            sender.text = context.getString(R.string.msg_sender, message.sender)
            edtMessage.setText(message.message)
            read.setOnCheckedChangeListener { _, b ->
                message.read = b
            }
            if(message.read!=null)
                read.isSelected = message.read!!
        }
    }

}