package io.github.diegoflassa.littledropsofrain.data.entities

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth


data class Message (
    var emailSender : String? = FirebaseAuth.getInstance().currentUser!!.email,
    var sender : String? = FirebaseAuth.getInstance().currentUser!!.displayName,
    var title : String? = null,
    var message : String? = null,
    var creationDate : Timestamp? = Timestamp.now(),
    var read : Boolean? = false
){

    companion object{
        private const val EMAIL_SENDER= "emailSender"
        private const val SENDER= "sender"
        private const val TITLE= "title"
        private const val MESSAGE= "message"
        private const val CREATION_DATE= "creationDate"
        private const val READ= "read"
    }

    constructor(map: Map<String, Any>) : this() {
        fromMap(map)
    }

    fun toMap(): Map<String, Any?> {
        val result: HashMap<String, Any?> = HashMap()
        result[EMAIL_SENDER] = emailSender
        result[SENDER] = sender
        result[TITLE] = title
        result[MESSAGE] = message
        result[CREATION_DATE] = creationDate
        result[READ] = read
        return result
    }

    fun fromMap(map: Map<String, Any>){
        emailSender = map[EMAIL_SENDER] as String?
        sender = map[SENDER] as String?
        title = map[TITLE] as String?
        message = map[MESSAGE] as String?
        creationDate = map[CREATION_DATE] as Timestamp?
        read = map[READ] as Boolean?
    }
}